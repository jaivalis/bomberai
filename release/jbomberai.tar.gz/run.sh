#!/bin/bash
if [ "$1" == "benchmark" ]
then 
    java -Djava.library.path=$PWD/libs/lwjgl/lwjgl-2.9.0/native/linux -cp dist/jbomber.jar jbomber.Benchmark
else
    java -Djava.library.path=$PWD/libs/lwjgl/lwjgl-2.9.0/native/linux -jar dist/jbomber.jar
fi
